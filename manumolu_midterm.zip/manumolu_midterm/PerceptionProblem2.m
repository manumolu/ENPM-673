close all
I = imread('low-contrast-ex.png');

numofpixels = size(I,1)*size(I,2);
figure;
imshow(I);
title('Original Image');

%Step 1 --------- Histogram of given Image
figure;
H=imhist(I);
bar(H)

% Step 2-----------Normalized Histogram
figure;
Hnorm = H*256/numel(I);
bar(Hnorm)

% Step3----------------Generate New Histogram H' where H' = ?H

HCumulative = zeros(256,1);
for i = 2:256
    HCumulative(i) = Hnorm(i) + HCumulative(i-1)
end
bar(HCumulative)

% Step4---Create Destination Image Image[x,y] = H'[Source_Image[x,y]]

for x=1:800
    for y=1:1200
        image(x, y) = HCumulative(I(x, y));
    end
end

Final_Image = uint8(image);
imshow(Final_Image)













