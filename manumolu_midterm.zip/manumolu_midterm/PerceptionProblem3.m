%%% 3(a) Rotation around a fixed Frame

% PreMultiplication if Rotations are performed with respect to a fixed
% frame 

% i.e, R(0,2) = R*R(0,1) where R(0,2) is the total rotation matrix and
% R(0,1) is the first rotation with repect to the fixed frame and R(0,2) is
% the second rotation with respect to the fixed frame 

% Z axis- 30, X-Axis-45, w.r.t to the fixed frame

% R(Z,30) = [ cos30  - sin30  0
%             sin30    cos30  0
%               0        0    1]


% Similarly the Rest 

% 3(a) : R = R(X,45)*R(Z,30)

RX45 = [1,0,0;
      0, 0.7071,-0.7071;
      0,0.7071,0.7071]

RZ30 = [0.8660, -0.5,0;
        0.5, 0.8660, 0;
        0,0,1]
    
RFixedFrame = RX45*RZ30  %%%---------------------ANSWER FOR 3A------------------%%%%%

%% Similarly for 3b, but since the rotations are happening relative to the
%Current frame, the rotation matrices are postmultiplied.


%%% 3B--->>
RCurrentFrame = RZ30*RX45 %%%-----------------------ANSWER FOR 3B---------------%%%%%
    
   


