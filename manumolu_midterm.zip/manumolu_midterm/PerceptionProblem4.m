I_L = imread('tsukuba_l.png');
I_R = imread('tsukuba_r.png');
window = [];
window1 = [];

%%Aim: To generate Windows on both the Left and Right Images and compute
%%SSD, and then disparity.

I_L = double(I_L);
I_R = double(I_R);

%%% 3x3 Mask
vec3 = 0:2;
vec4 = 0:2;
[p,q] = meshgrid(vec3, vec4);
pairs = [p(:) q(:)];
pairs=pairs-1;

for i=22:287
     for j=22:383
        window=[];
        for p =1:9   % Generates the Window on I_L near given Point (i,j)
            X = I_L(i+pairs(p,1),j+pairs(p,2));
            window = [window;X];
        end
             
        Min_SSD = 80000000;
        for k=0:19 % Generating Windows upto 20 Pixels Left of (i,j) everytime a WIndow on I_R  is Generated '
            
            for q =1:9  % Generates the Window on I_R near given Point (i,j)
                Y = I_R(i+pairs(q,1),(j-k)+pairs(q,2));
                window1 = [window1;Y];
            end
            sum = 0;
            for h = 1: 9
                sum = sum + (window(h)-window1(h))^2; % SSD
            end
            window1 =[];
            if (sum<Min_SSD)
                Min_SSD = sum;
                min_k = j-k;
            end
        end
        disparity(i,j)= j-min_k;
    end 
end
disparity = histeq(disparity); % Histogram Equalization
disparity= uint8(disparity);
imshow(disparity)

        