PROBLEM 1--------------------------------------------------------------------------------------------- 

Status: Solved. The coordinates are transformed using given rotations, camera parameters etc. 

Output is observed when the program is run: 2 figures; one showing the original image, the other
is the transformed image. 

--------------------------------------------------------------------------------------------------------

PROBLEM 2-----------------------------------------------------------------------------------------------

Status: Solved. The histogram equalized image is observed as shown in output, code is commented and
several intermediate figures such as the normalized historgram etc will pop up if the code is run. 

--------------------------------------------------------------------------------------------------------

PROBLEM 3-----------------------------------------------------------------------------------------------

Status: Solved. Commented, Matlab only used to show the final rotation matrices. The Solution matrices
are observed if the code is run. 

---------------------------------------------------------------------------------------------------------

PROBLEM 4------------------------------------------------------------------------------------------------

Status: Output Observed. Have used a 3x3 window to compute SSD and then the disparity. 
Output was observed to be highly contrasted, so used histogram equalization. 

Solution is observed  as the code is run. 